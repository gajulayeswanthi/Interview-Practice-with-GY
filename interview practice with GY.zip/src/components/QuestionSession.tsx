import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useAppContext } from '@/contexts/AppContext';
import { ArrowLeft } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import VoiceControls from './VoiceControls';

interface QuestionSessionProps {
  sessionType: string;
}

const QuestionSession: React.FC<QuestionSessionProps> = ({ sessionType }) => {
  const { setCurrentScreen, setCurrentScore } = useAppContext();
  const [answer, setAnswer] = useState('');
  const [showEvaluation, setShowEvaluation] = useState(false);
  const [showActualAnswer, setShowActualAnswer] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const questions = {
    'tell-me-about-yourself': [
      'Tell me about yourself and your background.',
      'What are your greatest strengths?',
      'Where do you see yourself in 5 years?'
    ],
    'communication-skills': [
      'How do you handle conflict in the workplace?',
      'Describe a time when you had to explain something complex.',
      'How do you work in a team environment?'
    ]
  };

  const actualAnswers = {
    'tell-me-about-yourself': [
      'I am a dedicated professional with [X years] of experience in [field]. I have strong skills in [key skills] and am passionate about [relevant area]. I enjoy solving complex problems and contributing to team success.',
      'My greatest strengths include problem-solving, adaptability, and strong communication skills. I am detail-oriented and always strive for excellence in my work.',
      'In 5 years, I see myself in a leadership role where I can mentor others and contribute to strategic decisions while continuing to grow my technical expertise.'
    ],
    'communication-skills': [
      'I approach conflict by listening to all parties, understanding different perspectives, and finding common ground. I focus on the issue, not the person, and work towards a solution that benefits everyone.',
      'I break down complex information into simple, relatable terms and use examples or analogies. I check for understanding and encourage questions to ensure clarity.',
      'I believe in open communication, active listening, and supporting team members. I contribute my strengths while being open to learning from others.'
    ]
  };

  const currentQuestions = questions[sessionType as keyof typeof questions] || [];
  const currentActualAnswers = actualAnswers[sessionType as keyof typeof actualAnswers] || [];

  const handleEvaluate = () => {
    setShowEvaluation(true);
    const score = Math.floor(Math.random() * 30) + 70;
    setCurrentScore(score);
  };

  const handleNext = () => {
    if (currentQuestion < currentQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setAnswer('');
      setShowEvaluation(false);
      setShowActualAnswer(false);
    } else {
      setCurrentScreen('end-session');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Button 
          onClick={() => setCurrentScreen('welcome')} 
          variant="outline" 
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl capitalize">
              {sessionType.replace('-', ' ')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-4">
                Question {currentQuestion + 1}: {currentQuestions[currentQuestion]}
              </h3>
              
              <VoiceControls
                question={currentQuestions[currentQuestion]}
                onAnswerChange={setAnswer}
                answer={answer}
              />

              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Your Answer:</label>
                <Textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Your answer will appear here..."
                  rows={4}
                />
              </div>

              <div className="flex space-x-4 mb-4">
                <Button onClick={handleEvaluate} variant="default">
                  Evaluate
                </Button>
                <Button onClick={() => setShowActualAnswer(true)} variant="outline">
                  Actual Answer
                </Button>
                <Button onClick={handleNext} variant="secondary">
                  Next
                </Button>
              </div>

              {showEvaluation && (
                <div className="bg-green-50 p-4 rounded-lg mb-4">
                  <h4 className="font-semibold text-green-800">Evaluation:</h4>
                  <p className="text-green-700">Good answer! Consider adding more specific examples.</p>
                </div>
              )}

              {showActualAnswer && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Model Answer:</h4>
                  <p className="text-blue-700">{currentActualAnswers[currentQuestion]}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuestionSession;