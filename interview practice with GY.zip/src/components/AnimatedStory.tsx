import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';

const AnimatedStory: React.FC = () => {
  const { setCurrentScreen } = useAppContext();
  const [animationPhase, setAnimationPhase] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setAnimationPhase((prev) => (prev + 1) % 4);
    }, 4000); // Slower animation - 4 seconds per phase

    return () => {
      clearInterval(timer);
    };
  }, []);

  const handleUploadResume = () => {
    setCurrentScreen('welcome');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-600 mb-2">
            Interview Practice with GY
          </h1>
          <p className="text-gray-600">An AI-Powered Interview Coach</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 min-h-96 flex items-center justify-center relative overflow-hidden mb-8">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-purple-100 opacity-50"></div>
          
          <div className="relative z-10 text-center">
            <div className="flex justify-center items-center space-x-8 mb-6">
              <div className={`transition-all duration-2000 transform ${
                animationPhase >= 0 ? 'translate-x-0 opacity-100' : 'translate-x-20 opacity-0'
              }`}>
                <div className="text-6xl mb-2">😰</div>
                <p className="text-sm font-medium">Stressed Student</p>
              </div>
              
              <div className={`transition-all duration-2000 transform ${
                animationPhase >= 1 ? 'translate-x-0 opacity-100' : '-translate-x-20 opacity-0'
              }`}>
                <div className="text-6xl mb-2">😊💻</div>
                <p className="text-sm font-medium">Confident Friend</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className={`transition-all duration-2000 ${
                animationPhase >= 0 ? 'opacity-100' : 'opacity-0'
              }`}>
                <p className="text-lg font-medium text-gray-800">
                  Meet Sarah, worried about her upcoming interview...
                </p>
              </div>
              
              <div className={`transition-all duration-2000 ${
                animationPhase >= 1 ? 'opacity-100' : 'opacity-0'
              }`}>
                <p className="text-lg font-medium text-blue-600">
                  She notices Alex looking confident with his laptop
                </p>
              </div>
              
              <div className={`transition-all duration-2000 ${
                animationPhase >= 2 ? 'opacity-100' : 'opacity-0'
              }`}>
                <p className="text-lg font-medium text-green-600">
                  "I practiced using Interview Practice with GY app!"
                </p>
              </div>
              
              <div className={`transition-all duration-2000 ${
                animationPhase >= 3 ? 'opacity-100' : 'opacity-0'
              }`}>
                <p className="text-lg font-medium text-purple-600">
                  Sarah feels relieved and opens the app too! 📱✨
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={handleUploadResume}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg font-medium transition-colors"
          >
            Upload Resume
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnimatedStory;