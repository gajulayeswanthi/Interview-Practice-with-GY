import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Volume2, Mic, MicOff, Square } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface VoiceControlsProps {
  question: string;
  onAnswerChange: (answer: string) => void;
  answer: string;
}

const VoiceControls: React.FC<VoiceControlsProps> = ({ question, onAnswerChange, answer }) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const speakQuestion = () => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(question);
      utterance.rate = 0.8;
      utterance.onend = () => setIsSpeaking(false);
      speechSynthesis.speak(utterance);
    } else {
      toast({ title: 'Speech synthesis not supported', variant: 'destructive' });
    }
  };

  const startListening = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      
      recognition.onstart = () => {
        setIsListening(true);
        toast({ title: 'Listening... Speak now!' });
      };
      
      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          onAnswerChange(answer + ' ' + finalTranscript);
        }
      };
      
      recognition.onerror = () => {
        setIsListening(false);
        toast({ title: 'Speech recognition error', variant: 'destructive' });
      };
      
      recognition.onend = () => {
        setIsListening(false);
      };
      
      recognition.start();
      
      // Store recognition instance for stopping
      (window as any).currentRecognition = recognition;
    } else {
      // Fallback simulation
      setIsListening(true);
      toast({ title: 'Listening... (Simulated)' });
      setTimeout(() => {
        onAnswerChange(answer + ' This is a simulated voice input.');
        setIsListening(false);
        toast({ title: 'Voice input completed' });
      }, 3000);
    }
  };

  const stopListening = () => {
    if ((window as any).currentRecognition) {
      (window as any).currentRecognition.stop();
    }
    setIsListening(false);
    toast({ title: 'Voice input stopped' });
  };

  return (
    <div className="flex items-center space-x-4 mb-4">
      <Button
        onClick={speakQuestion}
        variant="outline"
        disabled={isSpeaking}
        className="flex items-center space-x-2"
      >
        <Volume2 className="w-4 h-4" />
        <span>{isSpeaking ? 'Speaking...' : 'Speak Question'}</span>
      </Button>
      
      <Button
        onClick={isListening ? stopListening : startListening}
        variant={isListening ? "destructive" : "default"}
        className="flex items-center space-x-2"
      >
        {isListening ? (
          <>
            <Square className="w-4 h-4" />
            <span>Stop Listening</span>
          </>
        ) : (
          <>
            <Mic className="w-4 h-4" />
            <span>Start Listening</span>
          </>
        )}
      </Button>
    </div>
  );
};

export default VoiceControls;