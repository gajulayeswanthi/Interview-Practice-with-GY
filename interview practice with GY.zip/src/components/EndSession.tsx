import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppContext } from '@/contexts/AppContext';
import { Trophy, Star, TrendingUp } from 'lucide-react';

const EndSession: React.FC = () => {
  const { currentScore, setCurrentScreen, user } = useAppContext();

  const getPerformanceFeedback = (score: number) => {
    if (score >= 90) return { text: 'Excellent', color: 'text-green-600', icon: Trophy };
    if (score >= 70) return { text: 'Very Good', color: 'text-blue-600', icon: Star };
    return { text: 'Needs Improvement', color: 'text-orange-600', icon: TrendingUp };
  };

  const feedback = getPerformanceFeedback(currentScore);
  const IconComponent = feedback.icon;

  const handleRestart = () => {
    setCurrentScreen('welcome');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl mb-4">Session Complete!</CardTitle>
          <div className="text-6xl mb-4">🎉</div>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="bg-white rounded-lg p-6 shadow-inner">
            <h3 className="text-xl font-semibold mb-4">Your Final Score</h3>
            <div className="text-6xl font-bold text-blue-600 mb-4">
              {currentScore}/100
            </div>
            <div className={`flex items-center justify-center space-x-2 ${feedback.color}`}>
              <IconComponent className="w-6 h-6" />
              <span className="text-xl font-semibold">{feedback.text}</span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg p-6">
            <h4 className="text-lg font-semibold mb-2">Performance Analysis</h4>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <div className="font-medium">Communication</div>
                <div className="text-blue-200">{Math.floor(currentScore * 0.9)}/100</div>
              </div>
              <div>
                <div className="font-medium">Technical Skills</div>
                <div className="text-blue-200">{Math.floor(currentScore * 1.1)}/100</div>
              </div>
              <div>
                <div className="font-medium">Confidence</div>
                <div className="text-blue-200">{Math.floor(currentScore * 0.95)}/100</div>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-lg font-medium text-yellow-800 mb-2">
              Hope this session helped you boost your skills, {user?.username}!
            </p>
            <p className="text-yellow-700 text-sm">
              Keep practicing to improve your interview performance. Good luck with your upcoming interviews!
            </p>
          </div>

          <div className="flex space-x-4 justify-center">
            <Button onClick={handleRestart} className="bg-blue-600 hover:bg-blue-700">
              Start New Session
            </Button>
            <Button 
              onClick={() => setCurrentScreen('welcome')} 
              variant="outline"
            >
              Back to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EndSession;