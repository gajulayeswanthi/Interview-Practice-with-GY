import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAppContext } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';
import { Upload, User, MessageCircle, Code } from 'lucide-react';

const WelcomeDashboard: React.FC = () => {
  const { user, resumeUploaded, setResumeUploaded, setCurrentScreen } = useAppContext();

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setResumeUploaded(true);
      toast({ title: 'Resume uploaded successfully!' });
    }
  };

  const handleCardClick = (cardType: string) => {
    setCurrentScreen(cardType);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-600 mb-2">
            Interview Practice with GY
          </h1>
          <p className="text-gray-600">An AI-Powered Interview Coach</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-6 text-center">
            Welcome, {user?.username}. Let's start your first session to build your career.
          </h2>
          
          <div className="text-center mb-8">
            <Label htmlFor="resume" className="block text-lg font-medium mb-4">
              Upload Resume
            </Label>
            <div className="flex items-center justify-center">
              <Button
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
                onClick={() => document.getElementById('resume')?.click()}
              >
                <Upload className="w-5 h-5 mr-2" />
                Upload Resume
              </Button>
              <Input
                id="resume"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleResumeUpload}
                className="hidden"
              />
            </div>
          </div>

          {resumeUploaded && (
            <div className="grid md:grid-cols-3 gap-6">
              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                onClick={() => handleCardClick('tell-me-about-yourself')}
              >
                <CardHeader className="text-center">
                  <User className="w-12 h-12 mx-auto mb-2" />
                  <CardTitle>Tell Me About Yourself</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm opacity-90">Practice introducing yourself professionally</p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow bg-gradient-to-r from-green-500 to-green-600 text-white"
                onClick={() => handleCardClick('communication-skills')}
              >
                <CardHeader className="text-center">
                  <MessageCircle className="w-12 h-12 mx-auto mb-2" />
                  <CardTitle>Communication Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm opacity-90">Improve your communication abilities</p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow bg-gradient-to-r from-purple-500 to-purple-600 text-white"
                onClick={() => handleCardClick('coding-questions')}
              >
                <CardHeader className="text-center">
                  <Code className="w-12 h-12 mx-auto mb-2" />
                  <CardTitle>Code with GY</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm opacity-90">Practice coding challenges</p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WelcomeDashboard;