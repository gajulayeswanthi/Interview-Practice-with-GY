import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import SignupForm from './SignupForm';
import SigninForm from './SigninForm';
import AnimatedStory from './AnimatedStory';
import WelcomeDashboard from './WelcomeDashboard';
import QuestionSession from './QuestionSession';
import CodingSession from './CodingSession';
import EndSession from './EndSession';

const AppLayout: React.FC = () => {
  const { currentScreen } = useAppContext();

  const renderScreen = () => {
    switch (currentScreen) {
      case 'signup':
        return <SignupForm />;
      case 'signin':
        return <SigninForm />;
      case 'dashboard':
        return <AnimatedStory />;
      case 'welcome':
        return <WelcomeDashboard />;
      case 'tell-me-about-yourself':
        return <QuestionSession sessionType="tell-me-about-yourself" />;
      case 'communication-skills':
        return <QuestionSession sessionType="communication-skills" />;
      case 'coding-questions':
        return <CodingSession />;
      case 'end-session':
        return <EndSession />;
      default:
        return <SignupForm />;
    }
  };

  return (
    <div className="min-h-screen">
      {(currentScreen === 'signup' || currentScreen === 'signin') && (
        <div className="bg-gradient-to-br from-blue-50 to-purple-50 min-h-screen">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-8">
              <h1 className="text-5xl font-bold text-blue-600 mb-2">
                Interview Practice with GY
              </h1>
              <p className="text-xl text-gray-600">An AI-Powered Interview Coach</p>
            </div>
            {renderScreen()}
          </div>
        </div>
      )}
      {(currentScreen === 'dashboard' || currentScreen === 'welcome' || 
        currentScreen === 'tell-me-about-yourself' || currentScreen === 'communication-skills' ||
        currentScreen === 'coding-questions' || currentScreen === 'end-session') && (
        renderScreen()
      )}
    </div>
  );
};

export default AppLayout;