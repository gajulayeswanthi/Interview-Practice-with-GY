import React, { createContext, useContext, useState } from 'react';

interface User {
  username: string;
  password: string;
  mobile: string;
}

interface AppContextType {
  currentScreen: string;
  setCurrentScreen: (screen: string) => void;
  user: User | null;
  setUser: (user: User | null) => void;
  isAuthenticated: boolean;
  setIsAuthenticated: (auth: boolean) => void;
  resumeUploaded: boolean;
  setResumeUploaded: (uploaded: boolean) => void;
  currentScore: number;
  setCurrentScore: (score: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentScreen, setCurrentScreen] = useState('signup');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [resumeUploaded, setResumeUploaded] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);

  return (
    <AppContext.Provider
      value={{
        currentScreen,
        setCurrentScreen,
        user,
        setUser,
        isAuthenticated,
        setIsAuthenticated,
        resumeUploaded,
        setResumeUploaded,
        currentScore,
        setCurrentScore,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};