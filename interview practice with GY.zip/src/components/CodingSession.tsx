import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAppContext } from '@/contexts/AppContext';
import { ArrowLeft, Play, CheckCircle, XCircle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import VoiceControls from './VoiceControls';

const CodingSession: React.FC = () => {
  const { setCurrentScreen, setCurrentScore } = useAppContext();
  const [selectedLanguage, setSelectedLanguage] = useState('python');
  const [code, setCode] = useState('');
  const [output, setOutput] = useState('');
  const [testsPassed, setTestsPassed] = useState<boolean | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [questionAnswer, setQuestionAnswer] = useState('');

  const questions = [
    {
      title: 'Write a function to reverse a string',
      description: 'Create a function that takes a string as input and returns the reversed string.',
      testCases: ['hello -> olleh', 'world -> dlrow'],
      question: 'Explain how you would approach solving the string reversal problem'
    },
    {
      title: 'Find the maximum number in an array',
      description: 'Write a function that finds the maximum number in an array of integers.',
      testCases: ['[1,2,3,4,5] -> 5', '[10,5,8,3] -> 10'],
      question: 'What algorithm would you use to find the maximum element efficiently?'
    }
  ];

  const sampleCode = {
    python: `def reverse_string(s):
    return s[::-1]

# Test the function
print(reverse_string("hello"))`,
    java: `public class Solution {
    public String reverseString(String s) {
        return new StringBuilder(s).reverse().toString();
    }
}`,
    javascript: `function reverseString(s) {
    return s.split('').reverse().join('');
}

console.log(reverseString("hello"));`
  };

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    setCode(sampleCode[language as keyof typeof sampleCode] || '');
  };

  const handleRunCode = () => {
    setOutput('Running code...');
    
    setTimeout(() => {
      const isCorrect = code.includes('reverse') || code.includes('[::-1]') || code.includes('StringBuilder');
      
      if (isCorrect) {
        setOutput('olleh\nTest cases passed ✅');
        setTestsPassed(true);
        setCurrentScore(85);
        toast({ title: 'Code executed successfully!', description: 'All test cases passed' });
      } else {
        setOutput('Error: Function not implemented correctly\nTest cases failed ❌');
        setTestsPassed(false);
        toast({ title: 'Test cases failed', variant: 'destructive' });
      }
    }, 2000);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setCode('');
      setOutput('');
      setTestsPassed(null);
      setQuestionAnswer('');
    } else {
      setCurrentScreen('end-session');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto">
        <Button 
          onClick={() => setCurrentScreen('welcome')} 
          variant="outline" 
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl">Code with GY</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">
                Question {currentQuestion + 1}: {questions[currentQuestion].title}
              </h3>
              <p className="text-gray-600 mb-4">{questions[currentQuestion].description}</p>
              
              <div className="mb-4">
                <h4 className="font-medium mb-2">Discussion Question:</h4>
                <p className="text-gray-700 mb-2">{questions[currentQuestion].question}</p>
                
                <VoiceControls
                  question={questions[currentQuestion].question}
                  onAnswerChange={setQuestionAnswer}
                  answer={questionAnswer}
                />
                
                <Textarea
                  value={questionAnswer}
                  onChange={(e) => setQuestionAnswer(e.target.value)}
                  placeholder="Your explanation will appear here..."
                  rows={3}
                  className="mb-4"
                />
              </div>
              
              <div className="mb-4">
                <h4 className="font-medium mb-2">Test Cases:</h4>
                <ul className="list-disc list-inside text-sm text-gray-600">
                  {questions[currentQuestion].testCases.map((testCase, index) => (
                    <li key={index}>{testCase}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Select Language:</label>
                  <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="python">Python</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                      <SelectItem value="javascript">JavaScript</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Code Editor:</label>
                  <Textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Write your code here..."
                    rows={12}
                    className="font-mono text-sm"
                  />
                </div>

                <Button onClick={handleRunCode} className="w-full mb-4">
                  <Play className="w-4 h-4 mr-2" />
                  Run Code
                </Button>
              </div>

              <div>
                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Output:</label>
                  <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm min-h-[200px] whitespace-pre-wrap">
                    {output || 'Output will appear here...'}
                  </div>
                </div>

                {testsPassed !== null && (
                  <div className={`p-4 rounded-lg mb-4 flex items-center space-x-2 ${
                    testsPassed ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
                  }`}>
                    {testsPassed ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <XCircle className="w-5 h-5" />
                    )}
                    <span className="font-medium">
                      {testsPassed ? 'Code executed successfully ✅' : 'Test cases failed ❌'}
                    </span>
                  </div>
                )}

                <Button onClick={handleNext} className="w-full" disabled={!testsPassed}>
                  Next Question
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CodingSession;