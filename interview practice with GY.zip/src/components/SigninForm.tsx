import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppContext } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

const SigninForm: React.FC = () => {
  const { user, setCurrentScreen, setIsAuthenticated } = useAppContext();
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSignin = () => {
    if (!formData.username || !formData.password) {
      toast({ title: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    if (user && formData.username === user.username && formData.password === user.password) {
      setIsAuthenticated(true);
      setCurrentScreen('dashboard');
      toast({ title: 'Account created successfully!' });
    } else {
      toast({ title: 'Invalid credentials', variant: 'destructive' });
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl text-center">Sign In</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="username">Username</Label>
          <Input
            id="username"
            name="username"
            value={formData.username}
            onChange={handleInputChange}
            placeholder="Enter username"
          />
        </div>
        <div>
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleInputChange}
            placeholder="Enter password"
          />
        </div>
        <Button onClick={handleSignin} className="w-full">
          Sign In
        </Button>
      </CardContent>
    </Card>
  );
};

export default SigninForm;