import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppContext } from '@/contexts/AppContext';
import { toast } from '@/components/ui/use-toast';

const SignupForm: React.FC = () => {
  const { setCurrentScreen, setUser } = useAppContext();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    mobile: ''
  });
  const [otp, setOtp] = useState('');
  const [showOtp, setShowOtp] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSignup = () => {
    if (!formData.username || !formData.password || !formData.mobile) {
      toast({ title: 'Please fill all fields', variant: 'destructive' });
      return;
    }
    
    // Generate 4-digit OTP
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(otp);
    setShowOtp(true);
    toast({ title: `OTP sent to ${formData.mobile}: ${otp}` });
  };

  const handleOtpVerification = () => {
    if (otp === generatedOtp) {
      setUser(formData);
      setCurrentScreen('signin');
      toast({ title: 'OTP verified successfully!' });
    } else {
      toast({ title: 'Invalid OTP', variant: 'destructive' });
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl text-center">Sign Up</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!showOtp ? (
          <>
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                placeholder="Enter username"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Enter password"
              />
            </div>
            <div>
              <Label htmlFor="mobile">Mobile Number</Label>
              <Input
                id="mobile"
                name="mobile"
                value={formData.mobile}
                onChange={handleInputChange}
                placeholder="Enter mobile number"
              />
            </div>
            <Button onClick={handleSignup} className="w-full">
              Send OTP
            </Button>
          </>
        ) : (
          <>
            <div>
              <Label htmlFor="otp">Enter OTP</Label>
              <Input
                id="otp"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="Enter 4-digit OTP"
                maxLength={4}
              />
            </div>
            <Button onClick={handleOtpVerification} className="w-full">
              Verify OTP
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default SignupForm;